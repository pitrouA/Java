package main.view.menubar;

import main.model.Level;

public interface Action {
	public void action(Level level);
}
