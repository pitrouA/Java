package main.view.menubar;

import javafx.scene.control.CustomMenuItem;

public class Help extends CustomMenuItem{
	
	Help(){
		this.setVisible(true);
	}
}
